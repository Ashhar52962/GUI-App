from setuptools import setup,find_packages

setup(
    name='Books',
    version='1.0.0',
    packages=find_packages(),
    url='',
    license='',
    author='Ashhar Ansari',
    author_email='ashhar52962@gmail.com',
    description='this is small book store'
)